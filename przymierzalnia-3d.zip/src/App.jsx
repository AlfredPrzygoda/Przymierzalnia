// Przymierzalnia 3D - Model człowieka z kończynami i głową
import React, { useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, useGLTF } from "@react-three/drei";

function HumanModel({ dimensions }) {
  // Prosty model człowieka z podstawowych brył
  const bodyHeight = dimensions.height / 100;
  const scale = bodyHeight / 1.7;

  return (
    <group scale={[scale, scale, scale]} position={[0, -1, 0]}>
      {/* Tułów */}
      <mesh position={[0, 0.6, 0]}>
        <cylinderGeometry args={[0.25, 0.3, 0.9, 32]} />
        <meshStandardMaterial color="lightblue" />
      </mesh>
      {/* Głowa */}
      <mesh position={[0, 1.2, 0]}>
        <sphereGeometry args={[0.2, 32, 32]} />
        <meshStandardMaterial color="peachpuff" />
      </mesh>
      {/* Ręce */}
      <mesh position={[-0.45, 0.6, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.07, 0.07, 0.5, 16]} />
        <meshStandardMaterial color="lightblue" />
      </mesh>
      <mesh position={[0.45, 0.6, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.07, 0.07, 0.5, 16]} />
        <meshStandardMaterial color="lightblue" />
      </mesh>
      {/* Nogi */}
      <mesh position={[-0.15, 0, 0]}>
        <cylinderGeometry args={[0.09, 0.09, 0.6, 16]} />
        <meshStandardMaterial color="lightblue" />
      </mesh>
      <mesh position={[0.15, 0, 0]}>
        <cylinderGeometry args={[0.09, 0.09, 0.6, 16]} />
        <meshStandardMaterial color="lightblue" />
      </mesh>
    </group>
  );
}

function ClothingModel({ file }) {
  const { scene } = useGLTF(file);
  return <primitive object={scene} position={[0, -1, 0]} />;
}

export default function App() {
  const [dimensions, setDimensions] = useState({
    height: 170,
    chest: 90,
    waist: 75,
    hips: 95,
  });
  const [clothingFile, setClothingFile] = useState(null);

  const handleChange = (e) => {
    setDimensions({ ...dimensions, [e.target.name]: Number(e.target.value) });
  };

  const handleUpload = (e) => {
    const file = URL.createObjectURL(e.target.files[0]);
    setClothingFile(file);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold mb-4 text-center">Wirtualna Przymierzalnia</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Formularz wymiarów */}
        <div className="bg-white rounded-2xl shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Twoje wymiary</h2>
          {Object.entries(dimensions).map(([key, value]) => (
            <div className="mb-4" key={key}>
              <label className="block mb-1 capitalize">{key}</label>
              <input
                type="number"
                name={key}
                value={value}
                onChange={handleChange}
                className="w-full border rounded px-3 py-2"
              />
            </div>
          ))}

          <div className="mt-4">
            <label className="block mb-1">Wgraj model ubrania (.glb)</label>
            <input type="file" accept=".glb" onChange={handleUpload} />
          </div>
        </div>

        {/* Model 3D */}
        <div className="bg-white rounded-2xl shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Podgląd 3D</h2>
          <div className="w-full h-96">
            <Canvas camera={{ position: [0, 1.5, 4] }}>
              <ambientLight intensity={0.5} />
              <directionalLight position={[2, 2, 2]} />
              <OrbitControls />
              <HumanModel dimensions={dimensions} />
              {clothingFile && <ClothingModel file={clothingFile} />}
            </Canvas>
          </div>
        </div>
      </div>
    </div>
  );
}

useGLTF.preload = (file) => {};
